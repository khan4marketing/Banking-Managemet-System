<!-- <?php 
  session_start();

  if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) { 
 
}else {
   header("Location: login.php");
}
 ?> -->
